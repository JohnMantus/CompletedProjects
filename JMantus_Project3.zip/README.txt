Names: Allen Deleon & John Mantus
Net IDs: adeleon & jmantus

Our project 3 is divided into 4 classes. We represent our map as a graph with
nodes and edges using Graph.java, Node.java and Edge.java respectively. Nodes 
represent intersections and edges represent roads. 

The first thing our program does is read in the input file. Data on the roads
and intersections are stored in separate HashMaps for quick and easy access. 
Distances between nodes is found using a Java implementation of the Haversine
formula (code found online and is cited in comments). The shortest path between
two nodes is calculated using an implementation of Dijkstra's algorithm. For 
drawing the actual map, we scaled the points based on the size of the frame and
looped through each road to draw them. The same thing was done for drawing the 
shortest route but on a subsection of roads.  

The runtime complexity of each algorithm is at most O(n). During any stage of 
the program, we either search through each interesection or through each road.
Storing these values in a HashMap allows us to have O(1) operations for searching
and storing. We originally had our roads stored in a LinkedList but found the 
runtime far too long (NYS did not display after hours of running). 

Detailed look at different classes:

StreetMap.java:
	
	private Graph graph;	//stores a graph that represents our map
	double[] extremes;	//stores min/max of latitudes and longitudes

Node.java:

	public String ID; //Intersection ID
	public double latitude; 
	public double longitude;
	LinkedList<Node> neighbors; //Other neighboring Nodes(vertices)
	HashMap<Node, Edge> connectingEdges; //connecting roads for other 
						intersections
	public Node parent; //Parent in the shortest path
	public double shortDist; //shortest route to next node
	public boolean included; //true if intersection is 
					included in shortest path

Edge.java:

	public String ID; //Road ID
	Node u,v; 	//two nodes for start and end of road
 	double weight; //Distance between start and end nodes
	
Graph.java:

	HashMap<String,Edge> allEdges; //all Roads
	HashMap<String, Node> allNodes; //all Intersections
	HashMap<Integer, Edge> shortestEdges; //Shortest path 

Within each class there are the following methods:

In Graph.java:
	
	connect(Edge r) - connects two nodes and adds it to the graph

In StreetMap.java:

	dijkstra(Graph g, Node s, Node dest) - finds shortest path from s 
	(source) to dest (destination) in the graph g

	connect(Node s, Node dest) - sorts shortest path between s and dest
	to be in correct order for giving directions from s to dest

	argsCheck(String args[]) - checks for valid arguments in cmd prompt
	and returns various values for various cases


All other code is either commented out (there to show thought process) or 
fall into the following categories: main method, constructors, paintComponent
or imported assets. 

Since we worked in a pair, we distributed the work by each of us doing 
sections of the project. Allen wrote the algorithms and the two classes
Nodes and Edges, John wrote the code to paint the roads onto the map and 
wrote the additional methods in order to read the files. After that was done,
we both began to debug the code and thought about different ways to improve 
the code's runtime.
