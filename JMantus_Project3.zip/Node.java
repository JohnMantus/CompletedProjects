import java.util.LinkedList;
import java.util.HashMap;

public class Node implements Comparable<Node>{ //Intersection
	public String ID; //Intersection ID
	public double latitude; 
	public double longitude;
	LinkedList<Node> neighbors; //Other neighboring Nodes(vertices)
	HashMap<Node, Edge> connectingEdges; //connecting roads for other intersections
	public Node parent; //Parent in the shortest path
	public double shortDist; //shortest route to next node
	public boolean included; //true if intersection is included in shortest path
	public final int inf = Integer.MAX_VALUE; 
	
	Node(double x, double y, String id){
		ID = id;
		latitude = x;
		longitude = y;
		neighbors = new LinkedList<Node>();
		connectingEdges = new HashMap<Node, Edge>();
		shortDist = inf;
		parent = null;
		included = false;
	}
	
	@Override
	public int compareTo(Node n) {
		if( this.shortDist == n.shortDist ) {
			return 0;
		}
		else if( this.shortDist < n.shortDist ) {
			return -1;
		}
		else {
			return 1;
		}

	}

	@Override
	public String toString() {
		return "Node [shortDist=" + shortDist + "]";
	}
	
	
	
	
}
