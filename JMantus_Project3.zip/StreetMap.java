import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Stack;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class StreetMap extends JPanel{
	
	private Graph graph;
	double[] extremes;
	
	public StreetMap(String filename) throws FileNotFoundException {
		File file = new File(filename);
		Scanner sc = new Scanner(file);
		
		graph =  new Graph();
		extremes = new double[4];
		
		double minLat = Double.MAX_VALUE;
		double maxLat = -1000000;
		
		double minLong = Double.MAX_VALUE;
		double maxLong = -100000;
		
		//Reads the lines to get the values of the intersections and roads
		while(sc.hasNextLine()) {
			String l = sc.nextLine();
			String[] t = l.split("\t");
	
			if(t[0].equals("i")) {
				String ID = t[1];
				double latitude = Double.parseDouble(t[2]);
				double longitude = Double.parseDouble(t[3]);
				
				if(latitude<minLat) {
					minLat= latitude;
				}
				else if(latitude>maxLat) {
					maxLat=latitude;
				}
				if(longitude<minLong) {
					minLong = longitude;
				}
				else if(longitude>maxLong) {
					maxLong = longitude;
				}
				
				Node intersection = new Node(latitude, longitude, ID);
				graph.allNodes.put(ID, intersection);
			}
			else if(t[0].equals("r")) {
				String ID = t[1];
				Node start = graph.allNodes.get(t[2]);
				Node end = graph.allNodes.get(t[3]);
				Edge road = new Edge(start,end,ID);
				graph.connect(road);

			}
		}
		
		extremes[0] = minLong;
		extremes[1] = maxLong;
		extremes[2] = minLat;
		extremes[3] = maxLat;
		
	}
	
	private static final long serialVersionUID = 1L;
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D) g;
		
		int width = getWidth();
		int height = getHeight();
		
		int gwidth = width - width/10;
		int gheight = height - height/10;
		//System.out.println("GHeight :" + gheight);
		//double[] extremes = findExtremes();
		
		double minLong = extremes[0];
		double minLat = extremes[2];
		
		double maxLong = extremes[1];
		double maxLat = extremes[3];
		
		//System.out.println("Max/Min Lat: " + maxLat + ", " + minLat);
		//System.out.println("Max/Min Long: " + maxLong + ", " + minLong);
		
		//double RangeLong= minLong + maxLong;
		//double RangeLat = maxLat - minLat;
		
		//Draws the Map 
		for(Edge road : graph.allEdges.values()) {
			
			double x1 = road.u.longitude;
			double y1 = road.u.latitude;
			//System.out.println("First Y1: " + y1);
			
			
			double x2 = road.v.longitude;
			double y2 = road.v.latitude;
			//System.out.println("");
			
			//Adjustments
			x1 += Math.abs(minLong);
			x2 += Math.abs(minLong);
			//System.out.println("X1: " + x1);
			//System.out.println("X2: " + x2);
			
			y1 -=Math.abs(minLat);
			y2 -= Math.abs(minLat);
			
			//System.out.println("Y1: " + y1);
			//System.out.println("Y2: " + y2);
			
			//Longitudinal scaling
			x1= 50+(x1/(maxLong+Math.abs(minLong)))* gwidth;
			x2 = 50+(x2/(maxLong+Math.abs(minLong)))* gwidth;
			
			y1 = (y1/(maxLat-minLat)) * gheight;
			y2 = (y2/(maxLat-minLat)) * gheight;
			
			//System.out.println(x1 + " " + y1 + " | " + x2 + " " + y2);
			
			Line2D.Double line = new Line2D.Double();
			line.setLine(x1, gheight-y1+50 , x2, gheight-y2+50);
			
			g2.draw(line);
		}
		
		//Draws the shortest path
		for(Edge road : graph.shortestEdges.values()) {
			
			double x1 = road.u.longitude;
			double y1 = road.u.latitude;
			//System.out.println("First Y1: " + y1);
			
			
			double x2 = road.v.longitude;
			double y2 = road.v.latitude;
			//System.out.println("");
			
			//Adjustments
			x1 += Math.abs(minLong);
			x2 += Math.abs(minLong);
			//System.out.println("X1: " + x1);
			//System.out.println("X2: " + x2);
			
			y1 -=Math.abs(minLat);
			y2 -= Math.abs(minLat);
			
			//System.out.println("Y1: " + y1);
			//System.out.println("Y2: " + y2);
			
			//Longitudinal scaling
			x1= 50+(x1/(maxLong+Math.abs(minLong)))* gwidth;
			x2 = 50+(x2/(maxLong+Math.abs(minLong)))* gwidth;
			
			y1 = (y1/(maxLat-minLat)) * gheight;
			y2 = (y2/(maxLat-minLat)) * gheight;
			
			//System.out.println(x1 + " " + y1 + " | " + x2 + " " + y2);
			
			Line2D.Double line = new Line2D.Double();
			line.setLine(x1, gheight-y1+50 , x2, gheight-y2+50);
			
			g2.setPaint(Color.red);
			g2.setStroke(new BasicStroke(5));
			g2.draw(line);
		}
	}
	
	//Dijkstra algorithm used to find the shortest dist from the source to a destination
	public void dijkstra(Graph g, Node s, Node dest) {
		PriorityQueue<Node> pq = new PriorityQueue<Node>();
		HashMap<String,Node> allVert = g.allNodes;
		
		allVert.get(s.ID).shortDist = 0;
		allVert.get(s.ID).parent = null;
		pq.addAll(allVert.values());
		while(!pq.isEmpty()) {
			Node current = pq.poll();
			LinkedList<Node> neighbors = current.neighbors;
			
			for(Node n: neighbors) {
					double weightCost = current.connectingEdges.get(n).weight;
					if(n.shortDist > current.shortDist + weightCost) {
						n.shortDist = current.shortDist + weightCost;
						n.parent = current;
						pq.remove(n);
						pq.add(n);
					}
			}
		}
		
		//This if statement is used when the user wants to show
		//The map only and does not want to show the shortest path
		if(s != null && dest != null) {
			sort(s,dest);
		}
	}
	
	//Method retrieves the road path of the shortest dist
	public void sort(Node src, Node dest){
		LinkedList<Node> backwards = new LinkedList<Node>();
		Node parent = dest.parent;
		backwards.add(dest);
		while(parent != null) {
			backwards.add(parent);
			parent = parent.parent;
		}
		
		Stack<Node> stack = new Stack<Node>();
		
		stack.addAll(backwards);

		LinkedList<Node> output = new LinkedList<>();
		
		for(int i = 0; i<backwards.size(); i++) {
			output.add(stack.pop());
		}
		
		for(int i = 0; i<output.size()-1; i++) {
			graph.shortestEdges.put(i, output.get(i).connectingEdges.get(output.get(i+1)));
		}
//		System.out.println(graph.shortestEdges.toString());
//		graph.shortestEdges = output;
		/*for(int i = 0; i < stack.size(); i++) {
			sorted.add(stack.pop());
		}
		
		graph.shortestpath = sorted;*/
	}
	
/*	public double maxLong() {
		double max = -1000000;
		
		
		return max;
	}
	
	public double maxLat() {
		double max = 0;
		
		for(int i = 0; i<graph.allEdges.size(); i++) {
			if(graph.allEdges.get(i).u.latitude>max) {
				max =graph.allEdges.get(i).u.latitude;
			}
			if(graph.allEdges.get(i).v.latitude>max) {
				max = graph.allEdges.get(i).v.latitude;
			}
		}
		return max;
	}
		
	public double minLong() {
		double min = Double.MAX_VALUE;
		
		for(int i = 0; i<graph.allEdges.size(); i++) {
			if(graph.allEdges.get(i).u.longitude<min) {
				min =graph.allEdges.get(i).u.longitude;
			}
			if(graph.allEdges.get(i).v.longitude<min) {
				min = graph.allEdges.get(i).v.longitude;
			}
		}
		return min;
	}
	
	public double minLat() {
		double min = Double.MAX_VALUE;
		
		for(int i = 0; i<graph.allEdges.size(); i++) {
			if(graph.allEdges.get(i).u.latitude<min) {
				min =graph.allEdges.get(i).u.latitude;
			}
			if(graph.allEdges.get(i).v.latitude<min) {
				min = graph.allEdges.get(i).v.latitude;
			}
		}
		return min;
	}*/
	
	/*public double[] findExtremes() {
		
		double[] extremes = new double[4];
		
		
		
		for(int i = 0; i<graph.allEdges.size(); i++) {
			//find maximum longitude
			if(graph.allEdges.get(i).u.longitude>maxLong) {
				maxLong =graph.allEdges.get(i).u.longitude;
			}
			if(graph.allEdges.get(i).v.longitude>maxLong) {
				maxLong = graph.allEdges.get(i).v.longitude;
			}
			//find minimum longitude
			if(graph.allEdges.get(i).u.longitude<minLong) {
				minLong =graph.allEdges.get(i).u.longitude;
			}
			if(graph.allEdges.get(i).v.longitude<minLong) {
				minLong = graph.allEdges.get(i).v.longitude;
			}
			//Find maximum latitude
			if(graph.allEdges.get(i).u.latitude>maxLat) {
				maxLat =graph.allEdges.get(i).u.latitude;
			}
			if(graph.allEdges.get(i).v.latitude>maxLat) {
				maxLat = graph.allEdges.get(i).v.latitude;
			}
			//Find minimum latitude
			if(graph.allEdges.get(i).u.latitude<minLat) {
				minLat =graph.allEdges.get(i).u.latitude;
			}
			if(graph.allEdges.get(i).v.latitude<minLat) {
				minLat = graph.allEdges.get(i).v.latitude;
			}
			
		}
		extremes[0] = minLat; //Minimum LATITUDE
		extremes[1] = maxLat;	//Max latitude
		extremes[2] = minLong;	//Minimum longitude
		extremes[3] = maxLong;	//Maximum longitude
		return extremes;
		
		
	}*/
	
	//Method checks for valid arguements in the CMD
	public static int argsCheck(String args[]) {
		if(args.length < 2) {
			return 0;
		}
		else if( args.length == 2 && args[1].equals("--show")) {
			return 1;
		}
		else if( args.length == 4 && args[1].equals("--directions")) {
			return 2;
		}
		else if( args.length == 5 && args[1].equals("--show") && args[2].equals("--directions")) {
			return 3;
		}
		else if( args.length == 5 && args[1].equals("--directions") && args[4].equals("--show")) {
			return 4;
		}
		return 0;
	}
	
	public static void main (String[] args) throws FileNotFoundException {
		StreetMap map = new StreetMap(args[0]);
		JFrame frame = new JFrame();
		frame.add(map);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,800);
		
		int argsCheck = argsCheck(args);
		
		if(argsCheck == 0) {
			System.out.println("Invalid input.");
		}
		//Only show the Map
		else if(argsCheck == 1) {
			frame.setVisible(true);	
			map.dijkstra(map.graph,null,null);
		}
		
		//Only prints out the shortest path distance of two intersections
		else if(argsCheck == 2) {
			frame.setVisible(false);
			Node start = map.graph.allNodes.get(args[2]);
			Node end = map.graph.allNodes.get(args[3]);
			map.dijkstra(map.graph,start,end);
			double shortDist = 0;
			int size = map.graph.shortestEdges.size();
			for(int i = 0; i<size;i++) {
				System.out.println(map.graph.shortestEdges.get(i).u.ID);
				shortDist += map.graph.shortestEdges.get(i).weight;
			}
			System.out.println(map.graph.shortestEdges.get(size-1).v.ID);
			System.out.println("Shortest Dist: " + shortDist + " Miles");
		}
		
		//Last two conditions checks for the placement of --directions and --show in CMD
		else if(argsCheck == 3) {
			frame.setVisible(true);
			Node start = map.graph.allNodes.get(args[3]);
			Node end = map.graph.allNodes.get(args[4]);
			map.dijkstra(map.graph,start,end);
			double shortDist = 0;
			int size = map.graph.shortestEdges.size();
			for(int i = 0; i<size;i++) {
				System.out.println(map.graph.shortestEdges.get(i).u.ID);
				shortDist += map.graph.shortestEdges.get(i).weight;
			}
			System.out.println(map.graph.shortestEdges.get(size-1).v.ID);
			System.out.println("Shortest Dist: " + shortDist + " Miles");
		}
		else {
			frame.setVisible(true);
			Node start = map.graph.allNodes.get(args[2]);
			Node end = map.graph.allNodes.get(args[3]);
			map.dijkstra(map.graph,start,end);
			double shortDist = 0;
			int size = map.graph.shortestEdges.size();
			for(int i = 0; i<size;i++) {
				System.out.println(map.graph.shortestEdges.get(i).u.ID);
				shortDist += map.graph.shortestEdges.get(i).weight;
			}
			System.out.println(map.graph.shortestEdges.get(size-1).v.ID);
			System.out.println("Shortest Dist: " + shortDist + " Miles");
		}
	}
}
