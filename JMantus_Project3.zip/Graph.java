import java.util.HashMap;

public class Graph {
	HashMap<String,Edge> allEdges; //all Roads
	HashMap<String, Node> allNodes; //all Intersections
	HashMap<Integer, Edge> shortestEdges; //Shortest path 
//	double shortDist;

	
	public Graph(){
		allEdges = new HashMap<String,Edge>();
		allNodes = new HashMap<String, Node>();
		shortestEdges = new HashMap<Integer, Edge>();
	}
	
	//Adds Nodes to the Graph (to the HashMap)
	public void addNode(Node i) {
		allNodes.put(i.ID, i);
	}
	
	//connects the two nodes of a Edge and adds distance
	public void connect(Edge r) {
		Node u = r.u;
		Node v = r.v;
		//adds to the list of neighbors for each node
		//and adds the connecting Edge to the linked list
		//of each node
		u.neighbors.add(v);
		u.connectingEdges.put(v, r);
		v.neighbors.add(u);
		v.connectingEdges.put(u, r);
		
		r.weight = calculateWeight(u,v);
		allEdges.put(r.ID, r); //adds to the list of Edges
	}
	
	//calculates the distance(weight) using Haversine formula
	//Method found online but I had to modify it a bit
	//Source: https://rosettacode.org/wiki/Haversine_formula#Java
	public double calculateWeight(Node u, Node v) {
	    double R = 6372.8; // In kilometers
	    Node node1 = u;
	    Node node2 = v;
	    double dLat = Math.toRadians(node2.latitude - node1.latitude);
	    double dLon = Math.toRadians(node2.longitude - node1.longitude);
	    double lat1 = Math.toRadians(u.latitude);
	    double lat2 = Math.toRadians(v.latitude);

	    double a = Math.pow(Math.sin(dLat / 2),2) + Math.pow(Math.sin(dLon / 2),2) * Math.cos(lat1) * Math.cos(lat2);
	    double c = 2 * Math.asin(Math.sqrt(a));
	    return R * c;
	    }
	
	
	
}