public class Edge { //Road 
	public String ID; //Edge ID
	Node u,v; //two nodes
 	double weight; //Distance between both nodes
	
	public Edge(Node node1, Node node2, String id) {
		u = node1;
		v = node2;
		ID = id;
	}
}
